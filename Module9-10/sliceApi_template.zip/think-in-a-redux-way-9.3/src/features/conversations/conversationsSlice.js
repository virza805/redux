import { createSlice } from "@reduxjs/toolkit";

const initialState = {};

const conversationsSlice = createSlice({
    name: "conversations",
    initialState,
    reducers: {},
});

export const {} = conversationsSlice.actions;
export default conversationsSlice.reducer;
